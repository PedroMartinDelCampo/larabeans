/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compresor;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author al342235
 */
public class Compresor extends Application {
    
    TextArea texto=new TextArea();
    Button comprimir=new Button("Comprimir");
    private Stage stage;
    
    @Override
    public void start(Stage primaryStage) {
        stage=primaryStage;
        texto.setLayoutX(10);
        texto.setLayoutY(40);
        comprimir.setLayoutX(200);
        comprimir.setLayoutY(10);
        comprimir.setOnAction((ActionEvent evt) -> {
            texto.setText(comprimir(readFile()));
        });
        stage.setScene(new Scene(new AnchorPane(texto, comprimir)));
        stage.show();
    }

    private String readFile(){
        try {
            FileChooser chooser=new FileChooser();
            File file=chooser.showOpenDialog(stage);
            ArrayList<Byte> bytes = new ArrayList<>(512);
            InputStream stream = new FileInputStream(file);
            byte next;
            while ((next = (byte) stream.read()) != -1){
                bytes.add(next);
            }
            byte[] textBytes = toArray(bytes);
            return new String(textBytes);
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, "Error al leer archivo");
            return "";
        }
    }
    
    private byte[] toArray(ArrayList<Byte> bytes){
        byte[] b = new byte[bytes.size()];
        for (int i=0; i<bytes.size(); i++){
            b[i] = bytes.get(i);
        }
        return b;
    }
    
    private String comprimir(String text){
        LinkedHashMap<String, Integer> frecuencias=tablaFrecuencias(text);
        System.out.println("Tabla de frecuencias creada");
        ArrayList<Frecuencia> colaPrioritaria=cola(frecuencias);
        ArrayList<Frecuencia> f = new ArrayList<>(colaPrioritaria);
        System.out.println("Cola prioritaria creada");
        Tree<Frecuencia> tree = huffman(colaPrioritaria);
        tree.print();
        HashMap<String, ArrayList<Byte>> codes = createCodes(tree, f);
        return replace(text, codes);
    }
    
    private LinkedHashMap<String, Integer> tablaFrecuencias(String text){
        LinkedHashMap<String, Integer> tabla=new LinkedHashMap<>();
        while (!text.isEmpty()){
            char c=text.charAt(0);
            int count=0;
            int i;
            while ((i = text.lastIndexOf(c))!=-1){
                count++;
                text=remove(text, i);
            }
            tabla.put(String.valueOf(c), count);
        }
        return tabla;
    }
    
    private String remove(String text, int index){
        String r="";
        for (int i=0; i<text.length(); i++){
            if (i!=index){
                r+=text.charAt(i);
            }
        }
        return r;
    }
    
    private ArrayList<Frecuencia> cola(HashMap<String, Integer> frecuencias){
        ArrayList<Frecuencia> cola=new ArrayList<>();
        frecuencias.keySet().stream().forEach((c) -> {
            cola.add(new Frecuencia(c, frecuencias.get(c)));
        });
        Collections.sort(cola);
        return cola;
    }
    
    private Tree<Frecuencia> huffman(ArrayList<Frecuencia> cola){
        Tree<Frecuencia> efectiveRoot = null;
        for (int i=0; i<cola.size()-1; i++){
            Frecuencia f1 = cola.remove(0);
            Frecuencia f2 = cola.remove(0);
            Frecuencia f = new Frecuencia("z"+i, f1.getValue()+f2.getValue());
            
            cola.add(f);
            Collections.sort(cola);
            
            Tree<Frecuencia> left = new Tree<>(f1);
            Tree<Frecuencia> right = new Tree<>(f2);
            Tree<Frecuencia> root = new Tree<>(f);
            root.setRightChild(right);
            root.setLeftChild(left);
            efectiveRoot = root;
        }
        return efectiveRoot;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private HashMap<String, ArrayList<Byte>> createCodes(Tree<Frecuencia> tree,
            ArrayList<Frecuencia> keySet) {
        HashMap<String, ArrayList<Byte>> codes = new HashMap<>();
        keySet.stream().forEach((f) -> {
            codes.put(f.getKey(), Tree.findFrecuencia(tree, f, null));
        });
        return codes;
    }

    private String replace(String text, HashMap<String, ArrayList<Byte>> codes) {
        ArrayList<Byte> bytes = new ArrayList<>();
        chars(text).stream().map((c) -> codes.get(String.valueOf(c))).forEach((b) -> {
            if (b!=null){
                b.stream().forEach((bit) -> {
                    bytes.add(bit);
                });
            }
        });
        return new String(toArray(bytes));
    }
    
    private ArrayList<Character> chars(String s){
        ArrayList<Character> ch = new ArrayList<>();
        for (char c : s.toCharArray()){
            ch.add(c);
        }
        return ch;
    }
    
}
