/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compresor;

import java.util.Objects;

/**
 *
 * @author al342235
 */
public class Frecuencia implements Comparable<Frecuencia> {
    
    private String key;
    private int value;
    
    public Frecuencia(String c, int i){
        key=c;
        value=i;
    }
    
    public String getKey(){
        return key;
    }
    
    public int getValue(){
        return value;
    }
    
    @Override
    public int compareTo(Frecuencia f){
        if (value<f.getValue()){
            return -1;
        }
        return 1;
    }
    
    @Override
    public boolean equals(Object otra){
        if (otra instanceof Frecuencia){
            Frecuencia f = (Frecuencia) otra;
            return f.getKey().equals(key) && f.getValue()==value;
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.key);
        hash = 97 * hash + this.value;
        return hash;
    }
    
    @Override
    public String toString(){
        return "("+key+", "+value+")";
    }
    
}
