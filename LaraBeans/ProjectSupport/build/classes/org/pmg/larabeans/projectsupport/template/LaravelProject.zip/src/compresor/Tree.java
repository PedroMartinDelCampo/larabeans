/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compresor;

import java.util.ArrayList;

/**
 *
 * @author Pedro
 */
public class Tree<T> {
    
    private Tree<T> parent;
    private Tree<T> leftChild;
    private Tree<T> rightChild;
    private T key;
    
    public Tree(T key){
        this.key = key;
    }
    
    public void print(){
        if (isLeaf()){
            System.out.println(key);
        }
        if (leftChild!=null){
            leftChild.print();
        }
        System.out.println(key);
        if (rightChild!=null){
            rightChild.print();
        }
    }
    
    public Tree<T> getParent(){
        return parent;
    }
    
    public Tree<T> getLeftChild(){
        return leftChild;
    }
    
    public Tree<T> getRightChild(){
        return rightChild;
    }
    
    public void setParent(Tree<T> parent){
        this.parent = parent;
    }
    
    public void setLeftChild(Tree<T> left){
        left.setParent(this);
        leftChild = left;
    }
    
    public void setRightChild(Tree<T> right){
        right.setParent(this);
        rightChild = right;
    }
    
    public boolean isRoot(){
        return parent == null;
    }
    
    public boolean isLeaf(){
        return (leftChild == null) && (rightChild == null);
    }
    
    public T getKey(){
        return key;
    }
    
    public void setKey(T key){
        this.key = key;
    }
    
    public static ArrayList<Byte> findFrecuencia(Tree<Frecuencia> root, Frecuencia search,
            ArrayList<Byte> recorrido){
        if (recorrido == null){
            recorrido = new ArrayList<>();
        }
        if (root.isLeaf()){
            if (root.getKey().equals(search))
                return recorrido;
            return null;
        }
        Tree<Frecuencia> next;
        if (search.getValue() <= root.getKey().getValue()){
            recorrido.add((byte) 0);
            next = root.getLeftChild();
        } else {
            recorrido.add((byte) 1);
            next = root.getRightChild();
        }
        return findFrecuencia(next, search, recorrido);
    }
    
}
